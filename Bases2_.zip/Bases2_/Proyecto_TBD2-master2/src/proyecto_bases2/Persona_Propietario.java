/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_bases2;

/**
 *
 * @author Karen Medina
 */
public class Persona_Propietario extends Persona{

    public Persona_Propietario() {
    }

    public Persona_Propietario(String nombrePerson, String DNI) {
        super(nombrePerson, DNI);
    }
    
}
