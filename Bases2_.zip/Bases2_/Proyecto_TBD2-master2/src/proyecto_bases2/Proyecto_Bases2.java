/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_bases2;

import java.util.ArrayList;

/**
 *
 * @author Karen Medina
 */
public class Proyecto_Bases2 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        String[] columnasFarm = {"id_asignado", "Direccion","responsables"};
        String[] tipoDataFarm = {"text","text","text"};
        
        //Crear Keyspace
        /*String[] columnaLaborat = {"id_Lab", "plazoEntrega"};
        String[] tipoDataLaborat = {"text,","text"};
        CQL_Operaciones.IniciarConexion();
        CQL_Operaciones.Crear_KeySpace("rdf");
        CQL_Operaciones.finalizarConexion();
        */
        //Crear Tablas
        /*CQL_Operaciones.IniciarConexion();
        CQL_Operaciones.iniciarsesion("rdf");
        CQL_Operaciones.crear_tabla("farmacias", columnasFarm, tipoDataFarm, 0);
        CQL_Operaciones.finalizarConexion(); 
        */
        
        ArrayList<Persona> personas = new ArrayList();
        Persona p = new Persona("11234", "A");
        Persona p2 = new Persona("112345", "B");
        Persona p3 = new Persona("112346", "C");
        personas.add(p);
        personas.add(p2);
        personas.add(p3);
        Productos pro = new Productos("178864", "vitamina r", "mjkdk89", 7.0, 9.0, 10, true);
        Productos pro2 = new Productos("17886", "vitamina c", "mjkdk89", 7.0, 9.0, 10, true);
        ArrayList<Productos> prods = new ArrayList();
        prods.add(pro2);
        prods.add(pro);
        CrudFarmacia.create_farmacia("123456", "Kqikimart", personas, prods);
    }
    
}
